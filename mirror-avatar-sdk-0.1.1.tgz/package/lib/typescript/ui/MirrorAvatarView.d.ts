import React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import type { MirrorSession } from '../live/MirrorSession';
export interface MirrorAvatarViewProps {
    /** The call to render. Create it with MirrorSDK.createSession(). */
    session: MirrorSession;
    /** Shown in the top-left badge. */
    agentName?: string;
    /** Safe-area offsets. The SDK takes no safe-area dependency of its own. */
    insets?: {
        top?: number;
        bottom?: number;
        left?: number;
        right?: number;
    };
    /** Fired after the user hangs up, with the final banked duration. */
    onEnded?: (info: {
        durationMs: number;
    }) => void;
    /**
     * End-of-call summary buttons. Each renders only if its handler is given — the SDK owns no
     * navigation, so the host wires these to its own routes (e.g. a session-detail page and the
     * agent list). Omit both for a duration-only summary.
     */
    onViewSessionDetails?: () => void;
    onBackToAgents?: () => void;
    style?: StyleProp<ViewStyle>;
    /** Fires once the avatar model has loaded and the first frame is on screen. */
    onReady?: () => void;
}
/**
 * The full call experience: avatar + ambient glow + captions + controls, driven by one
 * session.
 */
export declare function MirrorAvatarView({ session, agentName, insets, onEnded, onViewSessionDetails, onBackToAgents, style, onReady, }: MirrorAvatarViewProps): React.JSX.Element;
//# sourceMappingURL=MirrorAvatarView.d.ts.map