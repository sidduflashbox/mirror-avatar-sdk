/**
 * Hold the display awake for as long as the caller is mounted.
 *
 * A call is watched, not touched, so the device's display timeout would otherwise sleep the
 * screen mid-conversation. Releasing on unmount is the point of tying this to a hook: the
 * screen must go back to the user's own timeout the moment the avatar leaves.
 *
 * Optional-chained rather than asserted so a host running an older native build — JS updated,
 * binary not yet shipped — degrades to the normal timeout instead of crashing.
 */
export declare function useKeepAwake(enabled?: boolean): void;
//# sourceMappingURL=useKeepAwake.d.ts.map