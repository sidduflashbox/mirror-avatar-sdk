import { Animated, type PanResponderInstance } from 'react-native';
export interface PipInsetsProp {
    top?: number;
    bottom?: number;
    left?: number;
    right?: number;
}
export interface PipWindow {
    /** True while collapsed to the corner card. */
    isPip: boolean;
    /**
     * The clip window (a plain View — safe to resize): position + size + rounded corners of the
     * visible card, plus the swipe-down offset. Spread onto the outer `overflow: hidden` frame.
     */
    windowStyle: {
        left: Animated.Value;
        top: Animated.Value;
        width: Animated.Value;
        height: Animated.Value;
        borderRadius: Animated.Value;
        transform: {
            translateY: Animated.Value;
        }[];
    };
    /**
     * The avatar surface: kept at a FIXED full-screen size and only transform-scaled/offset into the
     * card, so the native render surface is never resized (Android's Filament view is a TextureView,
     * which is unreliable across live resizes).
     */
    innerStyle: {
        left: Animated.Value;
        top: Animated.Value;
        width: number;
        height: number;
        transform: {
            scale: Animated.Value;
        }[];
    };
    /** Attach to the clip window. Recognises a downward swipe in fullscreen; owns drag + tap-to-expand in PiP. */
    panHandlers: PanResponderInstance['panHandlers'];
    /** Collapse fullscreen → corner card. */
    shrink: () => void;
    /** Expand corner card → fullscreen. */
    expand: () => void;
}
/**
 * Owns the floating-window interaction: fullscreen ⇄ corner morph, drag, and snap-to-nearest-
 * corner. The avatar surface is NEVER resized — it stays full-screen and is transform-scaled into
 * a clipping card, so we don't depend on Android's Filament TextureView tracking a live surface
 * resize. The geometry math lives in ./pipGeometry so it can be reasoned about alone.
 *
 * All values are JS-driven (`useNativeDriver: false`): the drag feeds `Animated.Value`s from the
 * gesture, and the width/height on the clip window are layout props that can't use the native
 * driver. It animates one small view, so this is smooth in practice.
 */
export declare function usePipWindow(insetsProp?: PipInsetsProp, opts?: {
    swipeToShrink?: boolean;
}): PipWindow;
//# sourceMappingURL=usePipWindow.d.ts.map