export type PipCorner = 'tl' | 'tr' | 'bl' | 'br';
export interface PipInsets {
    top: number;
    bottom: number;
    left: number;
    right: number;
}
export interface PipFrameConfig {
    /** Screen (or host container) size in px. */
    screenW: number;
    screenH: number;
    /** The floating window's size in px. */
    pipW: number;
    pipH: number;
    /** Gap kept between the window and the screen/safe-area edge. */
    margin: number;
    insets: PipInsets;
}
export interface Point {
    x: number;
    y: number;
}
export interface PipSizeConfig {
    /** Screen (or host container) width in px. */
    screenW: number;
    /** Card width as a fraction of screenW. */
    fraction: number;
    /** Clamp for the resulting width. */
    minW: number;
    maxW: number;
    /** width : height (e.g. 0.75 = 3:4 portrait). */
    aspect: number;
}
/**
 * The corner card's size, derived from the screen so it looks proportional everywhere: width is a
 * clamped fraction of the screen width; height follows the aspect. Rounded to whole px.
 */
export declare function pipSize(cfg: PipSizeConfig): {
    w: number;
    h: number;
};
export interface PipInner {
    scale: number;
    left: number;
    top: number;
}
/**
 * How to place the fixed, full-screen avatar surface inside the small corner card *without
 * resizing it* — the surface stays screenW×screenH and is only transform-scaled, so the native
 * render swapchain never changes size (Android's Filament TextureView is unreliable across live
 * resizes).
 *
 * The surface is scaled uniformly to the card width and offset vertically so the avatar's focus
 * point (`focusFrac` of screen height — roughly the head-and-shoulders centre) lands at the card's
 * middle. The card clips the rest. `scale` is applied about the view centre (React Native's
 * default), which the left/top offsets already account for.
 */
export declare function pipInnerTransform(screenW: number, screenH: number, pipW: number, pipH: number, focusFrac: number): PipInner;
/** The window's top-left corner, in screen px, for a given resting corner. */
export declare function cornerRect(corner: PipCorner, cfg: PipFrameConfig): Point;
/**
 * The corner nearest a window whose CENTRE is at (centerX, centerY). Split by the screen's
 * mid-lines — the quadrant the centre lands in is the corner it snaps home to.
 */
export declare function nearestCorner(centerX: number, centerY: number, screenW: number, screenH: number): PipCorner;
/**
 * Clamp a proposed top-left so the window stays fully on screen, inside the margin and safe
 * area. If the screen is too small to honour both edges, the min edge wins (the window never
 * drifts off the top-left).
 */
export declare function clampToScreen(x: number, y: number, cfg: PipFrameConfig): Point;
//# sourceMappingURL=pipGeometry.d.ts.map