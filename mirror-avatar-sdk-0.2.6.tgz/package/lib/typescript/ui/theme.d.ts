export declare const STAGE_BG = "#07070f";
/** The avatar occupies a band, not the whole screen. `top: 12vh; height: 52vh`. */
export declare const AVATAR_BAND_TOP = "12%";
export declare const AVATAR_BAND_HEIGHT = "52%";
/** `opacity: ended ? 0.45 : 1`, 700ms. */
export declare const AVATAR_ENDED_OPACITY = 0.45;
/** `linear-gradient(to bottom, transparent, #07070f 80%)`, height 200, bottom -48. */
export declare const FADE_HEIGHT = 200;
export declare const FADE_OFFSET = -48;
/** Ambient glow: `radial-gradient(ellipse 80% 70% at 50% 35%)` under `blur(80px)`. */
export declare const GLOW_ERROR = "rgba(220,50,50,0.04)";
export declare const GLOW_SPEAKING = "rgba(246,128,72,0.05)";
export declare const GLOW_LIVE = "rgba(40,69,214,0.06)";
export declare const GLOW_IDLE = "rgba(255,255,255,0.02)";
export declare const GLOW_FADE_MS = 1000;
export declare const GLOW_BLUR_PX = 80;
/** Pill chrome — the badge and the timer share it. */
export declare const PILL_BG = "rgba(255,255,255,0.06)";
export declare const PILL_BORDER = "rgba(255,255,255,0.08)";
export declare const BADGE_COLOR = "rgba(255,255,255,0.40)";
export declare const BADGE_FONT_SIZE = 11;
export declare const BADGE_LETTER_SPACING = 0.8;
export declare const TIMER_COLOR = "rgba(255,255,255,0.75)";
export declare const TIMER_FONT_SIZE = 12;
export declare const TIMER_ICON_COLOR = "rgba(255,255,255,0.50)";
export declare const CAPTION_COLOR = "rgba(255,255,255,0.85)";
export declare const CAPTION_FONT_SIZE = 15;
export declare const CAPTION_MAX_WIDTH = 448;
export declare const ERROR_COLOR = "rgba(248,113,113,0.7)";
export declare const ERROR_FONT_SIZE = 12;
export declare const ERROR_BOTTOM = 112;
/** Controls. 56×56 round mute; red end-call pill. */
export declare const CONTROL_SIZE = 56;
export declare const CONTROL_GAP = 24;
export declare const CONTROL_LABEL_COLOR = "rgba(255,255,255,0.45)";
export declare const CONTROL_LABEL_SIZE = 11;
export declare const MUTE_BG = "rgba(255,255,255,0.10)";
export declare const MUTE_BORDER = "rgba(255,255,255,0.15)";
export declare const MUTE_ACTIVE_BG = "#FB2C36";
export declare const END_BG = "#FB2C36";
export declare const END_PADDING_H = 32;
/** lucide renders at 24px (`h-6 w-6`). */
export declare const ICON_SIZE = 24;
/** Mic waveform equalizer. */
export declare const WAVE_H = 46;
export declare const WAVE_MAX_WIDTH = 220;
export declare const WAVE_BAR_SLOT = 7;
export declare const WAVE_BAR_MAX_W = 3.5;
export declare const WAVE_MUTED_OPACITY = 0.1;
export declare const WAVE_TOP_COLOR = "rgba(150,210,255,0.95)";
export declare const WAVE_BASE_COLOR = "rgba(0,136,255,0.55)";
/** Bright light-blue top → brand blue base, per bar. */
export declare const WAVE_BAR_GRADIENT = "linear-gradient(to bottom, rgba(150,210,255,0.95), rgba(0,136,255,0.55))";
export declare const WAVE_BAR_GLOW = "0 0 4px rgba(0,136,255,0.35)";
/** Entrance fade. */
export declare const ENTER_MS = 300;
export declare const ENTER_CONTROLS_MS = 600;
export declare const ENTER_CONTROLS_DELAY_MS = 200;
/** Reconnecting veil + end summary. */
export declare const VEIL_BG = "rgba(0,0,0,0.6)";
export declare const VEIL_CARD_BG = "#111120";
export declare const VEIL_CARD_WIDTH = 288;
/** Floating (picture-in-picture) window. Shrunk from fullscreen to a draggable corner card that
 *  stays live above the host app. Sized *relative to the screen* so it reads the same on a small
 *  phone, a large phone, or a tablet: its width is a fraction of the screen width (clamped to a
 *  sensible range), and its height follows a portrait aspect that suits the head-and-shoulders shot. */
export declare const PIP_WIDTH_FRACTION = 0.4;
export declare const PIP_MIN_WIDTH = 128;
export declare const PIP_MAX_WIDTH = 240;
export declare const PIP_ASPECT = 0.75;
export declare const PIP_MARGIN = 16;
export declare const PIP_RADIUS = 22;
/** The fullscreen surface is never resized for PiP (Android's Filament TextureView is unreliable
 *  across live resizes) — it's kept full-screen and transform-scaled into the card, centred on this
 *  fraction of screen height (≈ the head-and-shoulders shot). Tune to move the framing up/down. */
export declare const PIP_FOCUS_FRAC = 0.36;
export declare const PIP_MORPH_MS = 260;
/** A downward swipe on the fullscreen surface past this much travel (px) collapses it to the
 *  corner — the alternative to tapping the ⤡ button. A fast flick shrinks at a shorter distance. */
export declare const PIP_SWIPE_SHRINK_DY = 90;
/** Below this much finger travel (px), a press-and-release on the card counts as a tap → expand,
 *  rather than a drag. */
export declare const PIP_TAP_SLOP = 6;
/** Round shrink (⤡) button on the fullscreen surface. Sized to the badge/timer pill height, and
 *  it reuses the pill fill + hairline border (PILL_BG / PILL_BORDER) so the top row reads as one
 *  family rather than a heavier, oversized circle. */
export declare const PIP_SHRINK_BTN = 30;
export declare const PIP_BORDER = "rgba(255,255,255,0.12)";
/** End-of-call summary panel — a frosted `bg-black/40` card. React Native has no
 *  backdrop-blur, so the card leans a touch more opaque to stay legible over the moving avatar. */
export declare const SUMMARY_BG = "rgba(0,0,0,0.4)";
export declare const SUMMARY_BORDER = "rgba(255,255,255,0.08)";
export declare const SUMMARY_TITLE_COLOR = "rgba(255,255,255,0.85)";
export declare const SUMMARY_TIME_COLOR = "#FFFFFF";
export declare const SUMMARY_CLOCK_COLOR = "rgba(255,255,255,0.55)";
export declare const SUMMARY_LABEL_COLOR = "rgba(255,255,255,0.45)";
export declare const SUMMARY_AGENT_COLOR = "rgba(255,255,255,0.35)";
/** Primary "View session details" pill — `linear-gradient(135deg, #0088ff, #38a5ff)`. */
export declare const SUMMARY_ACCENT_GRADIENT = "linear-gradient(135deg, #0088ff, #38a5ff)";
export declare const SUMMARY_ACCENT_GLOW = "rgba(0,136,255,0.3)";
/** Secondary "Back" pill — `border-white/15 bg-white/[0.06]`. */
export declare const SUMMARY_SECONDARY_BG = "rgba(255,255,255,0.06)";
export declare const SUMMARY_SECONDARY_BORDER = "rgba(255,255,255,0.15)";
export declare const SUMMARY_SECONDARY_TEXT = "rgba(255,255,255,0.75)";
//# sourceMappingURL=theme.d.ts.map