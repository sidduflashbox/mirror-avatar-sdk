import type { MirrorLiveTransport } from './MirrorLiveTransport';
import type { MirrorAvatarError, MirrorCaption, MirrorSessionOptions, MirrorSessionState, MirrorViewBinding } from '../types';
interface Emitter {
    addListener: (name: string, cb: (e: any) => void) => {
        remove: () => void;
    };
}
/** Injectable seams — production uses the real RN native module + WebSocket. */
export interface MirrorSessionEnv {
    transport?: MirrorLiveTransport;
    nativeModule?: any;
    emitter?: Emitter;
    /** Injectable clock so the usage timer is testable. */
    now?: () => number;
}
/** What the packaged chrome (timer, captions, controls) subscribes to. */
export interface MirrorSessionListener {
    onState?: (state: MirrorSessionState) => void;
    onCaption?: (caption: MirrorCaption) => void;
    onError?: (error: MirrorAvatarError) => void;
}
/**
 * The public "call" object. Owns the WebSocket transport, the live-session state
 * machine, and the native audio module wiring. The consumer only ever touches
 * setToken / start / stop / mute / dispose / bindView + the option callbacks.
 */
export declare class MirrorSession {
    private opts;
    /**
     * Mic RMS of the most recent frame, 0 while muted. A mutable ref, not state — the
     * waveform samples it on the animation clock. Falls to 0 on teardown rather than freezing.
     */
    readonly micLevel: {
        current: number;
    };
    private native;
    private transport;
    private emitter;
    private session;
    private subs;
    private view;
    private token;
    private started;
    private now;
    private _sessionId;
    private listeners;
    /**
     * The last error raised, replayed to anything that subscribes afterwards. The host mounts the
     * view AFTER calling start(), so a fast failure — a wrong token-server address refuses the
     * connection in milliseconds — is raised before the view's chrome has subscribed. Without a
     * retained copy that error is emitted into an empty room and the call fails silently.
     */
    private lastError;
    private _state;
    private _muted;
    private usageMs;
    private segStart;
    private _startedAt;
    constructor(opts: MirrorSessionOptions, env?: MirrorSessionEnv);
    get state(): MirrorSessionState;
    get muted(): boolean;
    /** Epoch ms of the first connect, preserved across reconnects. Null until connected. */
    get startedAt(): number | null;
    /** Connected time only. Poll it — it does not notify. */
    getUsageMs(): number;
    /**
     * The packaged chrome subscribes here; returns an unsubscribe.
     *
     * Current state and any outstanding error are delivered immediately, so a listener that
     * arrives late still sees them — see [lastError].
     */
    subscribe(listener: MirrorSessionListener): () => void;
    /**
     * Client-side only — there is no server mute control. The mic stays open (so unmute is
     * instant) and the user's audio is replaced with silence on the way out, rather than
     * withheld: the server's turn detector needs to keep seeing frames to end a turn.
     */
    mute(muted: boolean): void;
    /** Manual token (alternative to the `getToken` provider) for simple/static use. */
    setToken(token: string): void;
    /** The view registers its shared-value writers so the session can drive lip-sync. */
    bindView(view: MirrorViewBinding): () => void;
    start(): Promise<void>;
    stop(): void;
    private teardownSubs;
    dispose(): void;
    private handleState;
    /** Bank the live segment. Idempotent. */
    private pauseUsage;
    /** Raise an error: retained for late subscribers, then delivered to current ones. */
    private raise;
    private emit;
}
export declare const MirrorSDK: {
    createSession: (opts: MirrorSessionOptions, env?: MirrorSessionEnv) => MirrorSession;
};
export {};
//# sourceMappingURL=MirrorSession.d.ts.map