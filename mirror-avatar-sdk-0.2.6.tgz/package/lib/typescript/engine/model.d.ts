export declare const MIRROR_MODEL_GLB_URL = "https://mirrorr.blr1.cdn.digitaloceanspaces.com/assets/3dmodels/face_white_nurse.glb";
//# sourceMappingURL=model.d.ts.map