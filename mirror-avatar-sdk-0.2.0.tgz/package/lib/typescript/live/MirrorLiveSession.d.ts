import type { MirrorLiveTransport, MirrorConnectionProvider } from './MirrorLiveTransport';
import type { LiveBlendshapeFrame } from './protocol';
import type { MirrorAvatarState, MirrorAvatarError } from '../types';
export interface MirrorLiveSessionDeps {
    enqueueAudioChunk: (pcmBase64: string, seq: number) => void;
    stopPlayback: () => void;
    setBlendshapes: (frames: LiveBlendshapeFrame[]) => void;
    stopFace: () => void;
    onState: (s: MirrorAvatarState) => void;
    onCaption: (c: {
        text: string;
        final: boolean;
    }) => void;
    onError: (e: MirrorAvatarError) => void;
    connectionProvider: MirrorConnectionProvider;
}
export declare class MirrorLiveSession {
    private transport;
    private deps;
    private pending;
    private framesBySeq;
    private earlyFrames;
    private unsub;
    private reconnectAttempts;
    private closed;
    private reconnecting;
    private proactiveTimer;
    private gapTimer;
    constructor(transport: MirrorLiveTransport, deps: MirrorLiveSessionDeps);
    private handle;
    private pump;
    private releaseHead;
    private drop;
    onChunkStarted(seq: number): void;
    private bargeIn;
    private clearPending;
    start(): Promise<void>;
    stop(): void;
    private scheduleReconnect;
    private scheduleProactive;
    private clearProactive;
    private proactiveRefresh;
    close(): void;
}
//# sourceMappingURL=MirrorLiveSession.d.ts.map