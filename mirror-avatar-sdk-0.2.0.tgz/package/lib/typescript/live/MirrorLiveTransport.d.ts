import type { MirrorLiveEvent, ClientControl } from './protocol';
export interface MirrorConnectionResult {
    token: string;
    expiresInMs?: number;
}
export type MirrorConnectionProvider = (ctx: {
    reason: 'start' | 'reconnect' | 'proactive';
}) => Promise<MirrorConnectionResult | null>;
export interface MirrorLiveTransport {
    connect(): void;
    sendAudioFrame(pcm: ArrayBuffer): void;
    sendControl(msg: ClientControl): void;
    close(): void;
    onEvent(listener: (e: MirrorLiveEvent) => void): () => void;
    setUrlToken?(token: string): void;
}
//# sourceMappingURL=MirrorLiveTransport.d.ts.map