import type { MirrorLiveTransport } from './MirrorLiveTransport';
import type { MirrorLiveEvent, ClientControl } from './protocol';
export declare class WebSocketLiveTransport implements MirrorLiveTransport {
    private baseUrl;
    private ws;
    private token;
    private listeners;
    constructor(baseUrl: string);
    setUrlToken(token: string): void;
    connect(): void;
    sendAudioFrame(pcm: ArrayBuffer): void;
    sendControl(msg: ClientControl): void;
    close(): void;
    onEvent(listener: (e: MirrorLiveEvent) => void): () => void;
    private dispatch;
}
//# sourceMappingURL=WebSocketLiveTransport.d.ts.map