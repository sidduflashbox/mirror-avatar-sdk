export declare function base64ToArrayBuffer(b64: string): ArrayBuffer;
//# sourceMappingURL=base64.d.ts.map