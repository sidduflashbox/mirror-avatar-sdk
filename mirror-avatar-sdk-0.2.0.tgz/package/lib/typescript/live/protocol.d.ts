export type MirrorLiveStatus = 'connecting' | 'live' | 'reconnecting' | 'ended' | 'error';
export interface LiveBlendshapeFrame {
    timestamp: number;
    blendshapes: Record<string, number>;
}
export type MirrorLiveEvent = {
    type: 'audio';
    seq: number;
    pcmBase64: string;
} | {
    type: 'blendshapes';
    seq: number;
    frames: LiveBlendshapeFrame[];
} | {
    type: 'caption';
    text: string;
    final: boolean;
} | {
    type: 'control';
    kind: 'stop_playback' | 'ended' | 'idle_prompt';
} | {
    type: 'status';
    status: MirrorLiveStatus;
    error?: unknown;
};
export type ClientControl = {
    type: 'stop';
} | {
    type: 'playback';
    seq: number;
};
export declare function encodeClientControl(msg: ClientControl): string;
export declare function parseServerMessage(data: string): MirrorLiveEvent | null;
//# sourceMappingURL=protocol.d.ts.map