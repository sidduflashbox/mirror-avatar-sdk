import React from 'react';
import type { MirrorSessionState } from '../types';
/** Glow hue per session state. */
export declare function glowColor(state: MirrorSessionState): string;
/**
 * A soft wash whose hue tracks the conversation: blue while listening, warm while the
 * agent speaks, red on error.
 *
 * The hue morphs over one second — a smooth colour interpolation where the glow never
 * disappears. React Native can't tween a gradient string, so we CROSS-FADE two stacked
 * layers: the outgoing hue fades out as the incoming hue fades in over the same second, so
 * the centre brightness stays roughly constant.
 *
 * (The previous single-layer version reset opacity to 0 and back on every change, which
 * blinked the whole glow out and in each time the agent started or stopped talking — the
 * "animation behind the model" that read as a pulse.)
 */
export declare function AmbientGlow({ state }: {
    state: MirrorSessionState;
}): React.JSX.Element;
//# sourceMappingURL=AmbientGlow.d.ts.map