/** Format a millisecond duration as `M:SS`. */
export declare function fmtClock(ms: number): string;
//# sourceMappingURL=fmtClock.d.ts.map