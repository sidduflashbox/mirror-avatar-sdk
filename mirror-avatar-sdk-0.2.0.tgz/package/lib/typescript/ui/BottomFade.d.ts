import React from 'react';
/**
 * Dissolves the avatar's lower edge into the backdrop.
 *
 * A real CSS gradient — React Native 0.76+ parses these, so this
 * needs no dependency and no slice-stack approximation (which banded visibly against the
 * bright skin and shirt).
 */
export declare function BottomFade(): React.JSX.Element;
//# sourceMappingURL=BottomFade.d.ts.map