import React from 'react';
import type { MirrorSession } from '../live/MirrorSession';
/** Top-left agent name. Hidden once the call ends. */
export declare function AgentBadge({ name }: {
    name: string;
}): React.JSX.Element | null;
/** A clock face drawn from two views (in place of a lucide <Clock/>). The stroke scales
 *  with size so it reads at the summary panel's 20px as well as the timer's 12px (at 12px the
 *  max clamps to 1.2, so the timer is unchanged). */
export declare function ClockGlyph({ size, color }: {
    size?: number | undefined;
    color?: string | undefined;
}): React.JSX.Element;
/**
 * Top-right elapsed time. Ticks once a second **while live only** — `getUsageMs()` banks
 * connected time, so the clock stops the moment the socket drops and resumes without
 * resetting. Owns its own state so the engine view never re-renders.
 */
export declare function CallTimer({ session }: {
    session: MirrorSession;
}): React.JSX.Element | null;
/** Cinematic subtitle — soft text over the scene, no chat bubble. Fades on change. */
export declare function Captions({ session }: {
    session: MirrorSession;
}): React.JSX.Element;
/** A quiet red line, not a dialog. */
export declare function ErrorWhisper({ session }: {
    session: MirrorSession;
}): React.JSX.Element | null;
//# sourceMappingURL=Chrome.d.ts.map