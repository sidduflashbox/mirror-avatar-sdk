import React from 'react';
/**
 * The end-of-call summary. Not a full-screen backdrop: a semi-transparent frosted card raised
 * over the still-animating (dimmed) avatar, carrying the session duration.
 *
 * The two buttons drive navigation the SDK does not own (e.g. a session-detail page and the
 * agent list), so each is exposed as an optional callback and rendered only when provided —
 * the same navigation-agnostic stance the SDK takes with tokens.
 */
export declare function EndCallSummary({ durationMs, agentName, onViewSessionDetails, onBackToAgents, }: {
    durationMs: number;
    agentName?: string;
    onViewSessionDetails?: () => void;
    onBackToAgents?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EndCallSummary.d.ts.map