import React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import type { ISharedValue } from 'react-native-worklets-core';
import type { AvatarEngine, BakedClip } from '../engine/AvatarEngine';
import type { MirrorSession } from '../live/MirrorSession';
export interface AvatarStageProps {
    /** The 3D engine port (Filament). */
    engine: AvatarEngine;
    session: MirrorSession;
    /** playStart sentinel clock: 0 idle, -1 start (latch), -2 stop + neutralize. */
    clock: ISharedValue<number>;
    clip: ISharedValue<BakedClip | null>;
    /** Camera dolly, eased on the render thread. See engine/camera.ts. */
    zoom: ISharedValue<number>;
    style?: StyleProp<ViewStyle>;
    onReady?: () => void;
}
/**
 * The avatar surface: renders the engine and drives lip-sync from the session.
 *
 * Holds NO React state. Re-rendering this subtree releases the engine's GPU buffers
 * out from under it, so every dynamic value flows through shared values or refs.
 */
export declare function AvatarStage({ engine, session, clock, clip, zoom, style, onReady, }: AvatarStageProps): React.JSX.Element;
//# sourceMappingURL=AvatarStage.d.ts.map