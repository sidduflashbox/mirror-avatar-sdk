import React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import type { MirrorSession } from '../live/MirrorSession';
export interface MirrorAvatarViewProps {
    /** The call to render. Create it with MirrorSDK.createSession(). */
    session: MirrorSession;
    /** Shown in the top-left badge. */
    agentName?: string;
    /** Safe-area offsets. The SDK takes no safe-area dependency of its own. */
    insets?: {
        top?: number;
        bottom?: number;
        left?: number;
        right?: number;
    };
    /** Fired after the user hangs up, with the final banked duration. */
    onEnded?: (info: {
        durationMs: number;
    }) => void;
    /**
     * End-of-call summary buttons. Each renders only if its handler is given — the SDK owns no
     * navigation, so the host wires these to its own routes (e.g. a session-detail page and the
     * agent list). Omit both for a duration-only summary.
     */
    onViewSessionDetails?: () => void;
    onBackToAgents?: () => void;
    style?: StyleProp<ViewStyle>;
    /** Fires once the avatar model has loaded and the first frame is on screen. */
    onReady?: () => void;
    /**
     * Mount as a floating overlay that can shrink to a draggable corner window (picture-in-picture)
     * and stay live above the host app's own screens. On the fullscreen surface a ⤡ button appears;
     * tapping it — or swiping the surface down — collapses the call to a corner card the user can
     * drag between corners and tap to expand. Starts fullscreen.
     *
     * Mount the view at your app root (above your navigator) so the call survives navigation — while
     * floating, its root is a full-screen `box-none` layer, so taps outside the corner card fall
     * through to your app and only the card is interactive.
     */
    floating?: boolean;
    /**
     * Fired when the user removes the floating window with the ✕ on the corner card. The call is
     * stopped; the host should drop the session / unmount the view in response. Only meaningful when
     * `floating`.
     */
    onDismiss?: () => void;
}
/**
 * The full call experience: avatar + ambient glow + captions + controls, driven by one
 * session.
 */
export declare function MirrorAvatarView({ session, agentName, insets, onEnded, onViewSessionDetails, onBackToAgents, style, onReady, floating, onDismiss, }: MirrorAvatarViewProps): React.JSX.Element | null;
//# sourceMappingURL=MirrorAvatarView.d.ts.map