/** RMS (~0..0.3 for speech) → 0..1. `Math.min(1, level * 7.5)`. */
export declare function normalizeLevel(rms: number): number;
/** Fast attack, slow release: `target > s ? target*0.65 + s*0.35 : s*0.88`. */
export declare function smoothLevel(previous: number, target: number): number;
/** Smoothstep over the outer 40% of each side, so bars fade well into the row. */
export declare function edgeFade(x: number): number;
/** Combined taper for a bar at normalized position `nx` ∈ [0,1]. */
export declare function edgeAt(nx: number): number;
/** Flowing per-bar height so the row reads as an organic envelope. */
export declare function wobble(nx: number, t: number): number;
/** Bar height in px. `amp = 5 + level*(H-6)`; `h = max(1, edge*amp*max(0.08, wob))`. */
export declare function barHeight(nx: number, smoothed: number, t: number, waveHeight: number): number;
//# sourceMappingURL=waveform.d.ts.map