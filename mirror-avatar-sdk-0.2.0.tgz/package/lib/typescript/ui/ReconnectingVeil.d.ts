import React from 'react';
/**
 * The reconnecting veil — a dark scrim over the whole stage with a centered card: a spinning
 * ring + "Reconnecting…". Shown while the socket is down and the SDK is re-minting a token to
 * resume the session.
 *
 * RN has no backdrop-blur, so the scrim is a flat dark wash (VEIL_BG) rather than a translucent
 * blurred panel.
 */
export declare function ReconnectingVeil(): React.JSX.Element;
//# sourceMappingURL=ReconnectingVeil.d.ts.map