import React from 'react';
import type { MirrorSession } from '../live/MirrorSession';
/** Video-call style: round mic toggle (red while muted) + a red end-call pill. */
export declare function CallControls({ session, onEnd, }: {
    session: MirrorSession;
    onEnd: () => void;
}): React.JSX.Element;
//# sourceMappingURL=CallControls.d.ts.map