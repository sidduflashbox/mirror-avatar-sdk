import React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
/** The shrink-to-corner (⤡) control shown on the fullscreen surface. */
export declare function ShrinkButton({ onPress, style, }: {
    onPress: () => void;
    style?: StyleProp<ViewStyle>;
}): React.JSX.Element;
/** The close/remove (✕) control shown on the corner card. */
export declare function CloseButton({ onPress, style, }: {
    onPress: () => void;
    style?: StyleProp<ViewStyle>;
}): React.JSX.Element;
//# sourceMappingURL=PipButtons.d.ts.map