import { Animated, type PanResponderInstance } from 'react-native';
export interface PipInsetsProp {
    top?: number;
    bottom?: number;
    left?: number;
    right?: number;
}
export interface PipWindow {
    /** True while collapsed to the corner card. */
    isPip: boolean;
    /** Animated geometry for the morphing frame — spread into the frame's style. */
    frameStyle: {
        left: Animated.Value;
        top: Animated.Value;
        width: Animated.Value;
        height: Animated.Value;
        borderRadius: Animated.Value;
        transform: {
            translateY: Animated.Value;
        }[];
    };
    /**
     * Attach to the morphing frame. In fullscreen it recognises a downward swipe (→ shrink) but
     * leaves taps for the call controls; in PiP it owns the drag + tap-to-expand.
     */
    panHandlers: PanResponderInstance['panHandlers'];
    /** Collapse fullscreen → corner card. */
    shrink: () => void;
    /** Expand corner card → fullscreen. */
    expand: () => void;
}
/**
 * Owns the floating-window interaction: fullscreen ⇄ corner morph, drag, and snap-to-nearest-
 * corner. Pure RN — `Animated` for the tween, `PanResponder` for the gesture. The geometry math
 * lives in ./pipGeometry so it can be reasoned about on its own.
 *
 * All values are JS-driven (`useNativeDriver: false`): the drag feeds `Animated.Value`s from the
 * gesture (which is JS-side anyway), and layout props like width/height can't use the native
 * driver. It animates a single small view, so this is smooth in practice.
 */
export declare function usePipWindow(insetsProp?: PipInsetsProp, opts?: {
    swipeToShrink?: boolean;
}): PipWindow;
//# sourceMappingURL=usePipWindow.d.ts.map