import React from 'react';
/**
 * Live mic-level equalizer. Bottom-anchored rounded bars whose heights track the mic RMS,
 * both ends tapering out. Dims to 0.1 while muted.
 *
 * Each bar is a View scaled about its bottom edge, driven from an animation frame loop — no
 * React state, so nothing above re-renders (which would release the engine's GPU buffers).
 *
 * `levelRef` is the session's `micLevel`, sampled rather than subscribed to.
 */
export declare function MicWaveform({ levelRef, active, }: {
    levelRef: {
        current: number;
    };
    active: boolean;
}): React.JSX.Element;
//# sourceMappingURL=MicWaveform.d.ts.map