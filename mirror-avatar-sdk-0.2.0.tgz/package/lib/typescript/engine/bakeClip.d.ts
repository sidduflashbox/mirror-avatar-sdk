import type { BakedClip, JointDrive } from './AvatarEngine';
export type StoryFrame = {
    timestamp: number;
    blendshapes: Record<string, number>;
};
export declare const JOINTS: JointDrive[];
export declare const POSE_STRIDE = 9;
export declare const baseName: (raw: string) => string;
export declare function buildBaseNameIndex(morphTargetNames: string[]): Record<string, number>;
export declare function bakeClip(morphTargetNames: string[], frames: StoryFrame[], mouthGain?: Record<string, number>): BakedClip;
//# sourceMappingURL=bakeClip.d.ts.map