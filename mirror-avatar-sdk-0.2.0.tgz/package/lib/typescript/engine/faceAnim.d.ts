export type FaceAnimConfig = {
    blinkDurationSec: number;
    blinkMinIntervalSec: number;
    blinkMaxIntervalSec: number;
    breathRate: number;
    breathAmp: number;
    restingSmile: number;
    headPitchRange: number;
    headYawRange: number;
    headRollRange: number;
    headSwayMinIntervalSec: number;
    headSwayMaxIntervalSec: number;
    headEaseBase: number;
    visemeTailSec: number;
    /**
     * Seconds to start a chunk's viseme clip AHEAD of its latch, to cancel the fixed latency
     * between a chunk's audio actually starting and the face latching it (native start-clock poll
     * → JS bridge → bakeClip → next render frame). Positive = advance the mouth (fixes a mouth that
     * TRAILS the voice); negative = delay it (mouth that LEADS). Tune on device to taste.
     */
    lipsyncLeadSec: number;
    mouthGain: Record<string, number>;
};
export declare const DEFAULT_FACE_ANIM_CONFIG: FaceAnimConfig;
export declare const IDLE_LAST_PASSED = 0;
export declare const IDLE_BLINK_START = 1;
export declare const IDLE_NEXT_BLINK_AT = 2;
export declare const IDLE_NEXT_SHIFT_AT = 3;
export declare const IDLE_TGT_PITCH = 4;
export declare const IDLE_TGT_YAW = 5;
export declare const IDLE_TGT_ROLL = 6;
export declare const IDLE_CUR_PITCH = 7;
export declare const IDLE_CUR_YAW = 8;
export declare const IDLE_CUR_ROLL = 9;
export declare const IDLE_SEED = 10;
export declare const IDLE_LEN = 11;
export declare function initIdleState(seed: number): number[];
export declare function prngNext(seed: number): {
    rand: number;
    seed: number;
};
export declare function blinkEnvelope(tSince: number, durationSec: number): number;
export declare function breath(t: number, rate: number, amp: number): number;
export declare function easeToward(current: number, target: number, easeBase: number, delta: number): number;
export type IdleMorphs = {
    blinkL: number;
    blinkR: number;
    jawOpen: number;
    smileL: number;
    smileR: number;
};
export declare function resolveIdleMorphs(morphTargetNames: string[]): IdleMorphs;
//# sourceMappingURL=faceAnim.d.ts.map