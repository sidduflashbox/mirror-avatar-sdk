export type ClipSample = {
    kind: 'end';
} | {
    kind: 'frame';
    index: number;
};
export declare function sampleClip(frameCount: number, fps: number, elapsedSeconds: number, holdSeconds?: number): ClipSample;
//# sourceMappingURL=clipSampler.d.ts.map