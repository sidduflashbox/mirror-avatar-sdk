export { filamentAvatarEngine } from './FilamentAvatarView';
//# sourceMappingURL=index.d.ts.map