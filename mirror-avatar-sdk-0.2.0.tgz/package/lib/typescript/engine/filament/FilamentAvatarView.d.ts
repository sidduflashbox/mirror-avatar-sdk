import type { AvatarEngine } from '../AvatarEngine';
export declare const filamentAvatarEngine: AvatarEngine;
//# sourceMappingURL=FilamentAvatarView.d.ts.map